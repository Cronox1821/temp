/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.util.ArrayList;
import java.util.List;
//Modelo.* == Importa todas las clases del package
import Modelo.*;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;

/**
 *
 * @author CETECOM
 */
public class Controlador {

    private List<Producto> productos = new ArrayList<>();
    private List<Categoria> categorias = new ArrayList<>();

    public Controlador() {
        //Datos de prueba para rellenar UI
        Categoria cat1 = new Categoria(1,"Audifonos");
        Categoria cat2 = new Categoria(2,"Accesorios");
        Categoria cat3 = new Categoria(3,"Cargador");
        categorias.add(cat1);
        categorias.add(cat2);
        categorias.add(cat3);
        Producto prod = new Producto(1,15,"Xiaomi Buds",55000,cat1);
        productos.add(prod);
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }

    public List<Categoria> getCategorias() {
        return categorias;
    }

    public void setCategorias(List<Categoria> categorias) {
        this.categorias = categorias;
    }

    //Personalizado 
    //Registrar y Listar productos
    //Agregar y listar Categorias
    //Vender Producto
    public String registrarProducto(int codigo, String nombre,
            double precio, int cantidad,
            int idCategoria, String nombreCategoria) {
        Categoria cat = new Categoria(idCategoria, nombreCategoria);
        Producto producto = new Producto(codigo, cantidad, nombre, precio, cat);
        productos.add(producto);
        return "Agregado con exito";
    }

    public String agregarCategoria(int codigo, String nombre) {
        Categoria categoria = new Categoria(codigo, nombre);
        categorias.add(categoria);
        return "Categoria agregada";
    }

    //Lista = DefaultListModel || Modelo de lista de Java Swing
    //Tabla = DefaultTableModel || Modelo de tabla de java swing 
    //ComboBox = DefaultComboBoxModel || Modelo de comboBox de java swing
    public DefaultListModel listarProductos() {
        DefaultListModel lista = new DefaultListModel();
        //Necesito recorrer la lista de productos
        for (Producto producto : productos) {
            //Ejemplo de muestra
            // 1 Xiaomi HeadPhone $50000 10 Unidades Audifonos
            lista.addElement(producto.getCodigo() + " "
                    + producto.getNombre() + " $"
                    + producto.getPrecio() + " "
                    + producto.getCantidad() + " Unidades  "
                    + producto.getCategoria().getNombre() + " ");
        }
        return lista;
    }

    public DefaultComboBoxModel listarCategorias() {
        DefaultComboBoxModel combo = new DefaultComboBoxModel();
        for (Categoria categoria : categorias) {
            combo.addElement(categoria.getNombre());
        }
        return combo;
    }

    public DefaultListModel filtrarPorCategoria(String categoria) {
        DefaultListModel lista = new DefaultListModel();
        for (Producto producto : productos) {
            if (producto.getCategoria().getNombre().equalsIgnoreCase(categoria)) {
                lista.addElement(producto.getCodigo() + " "
                        + producto.getNombre() + " $"
                        + producto.getPrecio() + " "
                        + producto.getCantidad() + " Unidades  "
                        + producto.getCategoria().getNombre() + " ");
            }
        }
        return lista;
    }

    public String venderProducto(int codigo, int cantidad) {
        for (Producto producto : productos) {
            if (producto.getCodigo() == codigo) {
                if (producto.getCantidad() - cantidad > 0) {
                    int nuevoStock = producto.getCantidad() - cantidad;
                    producto.setCantidad(nuevoStock);
                    return "Venta realizada por $" + (producto.getPrecio() * cantidad);
                } else {
                    return "Cantidad solicitada supera el stock actual";
                }
            }
        }
        return "Producto no existe";

    }

}
