/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Validador;

/**
 *
 * @author CETECOM
 */
public class Validador {

    public boolean validarNombre(String nombre) {
        return nombre.length() > 0;
    }

    public boolean validarPrecio(double precio) {
        return precio > 0;
    }

    public boolean validarCantidad(int cantidad) {
        return cantidad > 0;
    }
}
