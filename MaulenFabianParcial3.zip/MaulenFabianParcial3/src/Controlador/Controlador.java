/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;

public class Controlador {
    private List<Categoria> categorias = new ArrayList<>();
    private List<Producto> productos = new ArrayList<>();

    public Controlador() {
        Categoria cate1= new Categoria(1,"Mouse");
        Categoria cate2= new Categoria(1,"Audifonos");
        Categoria cate3= new Categoria(1,"Teclados");
        categorias.add(cate1);
        categorias.add(cate2);
        categorias.add(cate3);
        
        
    }

    public List<Categoria> getCategorias() {
        return categorias;
    }

    public void setCategorias(List<Categoria> categorias) {
        this.categorias = categorias;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }
    
    public String registrarProductos(int codigo,String nombre, double precio, int cantidad,int idCategoria, String nombreCategoria){
            Categoria cat1 = new Categoria(idCategoria, nombreCategoria);
            Producto prod1 = new Producto(codigo, cantidad,nombre,precio,cat1);
            productos.add(prod1);
            return "Agregado con exito :)";
    }
    
    public DefaultComboBoxModel listarCategorias(){
        DefaultComboBoxModel combo = new DefaultComboBoxModel();
        for(Categoria categoria : categorias){
            combo.addElement(categoria.getNombre());
        }
        return combo;
    }
    
    public DefaultListModel ListarProductos(){
        DefaultListModel listaprod = new DefaultListModel();
        for(Producto producto : productos){
            listaprod.addElement(producto.getIdProducto() + " " + producto.getNombre() + " " + producto.getCategoria().getNombre() + "   $" + producto.getPrecio() + " " + producto.getCantidadInventario());
        }
        return listaprod;
    }
    
    public String venderProducto(int codigo, int cantidad){
        for(Producto producto : productos){
            if(producto.getIdProducto()==codigo){
                if(producto.getCantidadInventario()-cantidad>=0){
                    int nuevoStock = producto.getCantidadInventario()-cantidad;
                    producto.setCantidadInventario(nuevoStock);
                    return "Venta realizada";
                }else{
                    return "No hay stock suficiente";
                }
            }
        }
        return "Producto no existe";
                }
    
    
    
    
}
